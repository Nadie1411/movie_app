import 'package:flutter/material.dart';

class SearchTab extends StatelessWidget {
  static const String routeName = 'search_tab';

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
