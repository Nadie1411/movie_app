



import 'package:cloud_firestore/cloud_firestore.dart';

import '../../Widgets/movies.dart';

class FirebaseUtils{

static CollectionReference<Movies> getMoviesCollection(){
  return   FirebaseFirestore.instance.collection(Movies.collectionName).
  withConverter<Movies>(
        fromFirestore: ((snapshot,options)=>Movies.fromFireStore(snapshot.data()!)),
      toFirestore:(movie,options)=>movie.toFireStore());






}


static Future <void> addMovieToFireStore(Movies movies)async{
  var movieCollection=getMoviesCollection();
 var movieDocRef= movieCollection.doc('');
 movies.id=movieDocRef.id;
 await movieDocRef.set(movies);
  print('Movie added with ID: ${movies.id}'); // Add this line for debugging


}
static Future<void> removeMovieFromFireStore(String movieId) async {
  var movieCollection = getMoviesCollection();
  await movieCollection.doc(movieId).delete();
}


}