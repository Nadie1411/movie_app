import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final CollectionReference watchlistCollection =
  FirebaseFirestore.instance.collection('watchlist');

  // Add a movie to the Firestore watchlist collection
  Future<void> addMovieToWatchlist(Map<String, dynamic> movieData) async {
    try {
      await watchlistCollection.add(movieData);
    } catch (e) {
      print("Error adding movie to watchlist: $e");
    }
  }

  // Get the movies saved in the watchlist
  Stream<List<Map<String, dynamic>>> getWatchlistMovies() {
    return watchlistCollection.snapshots().map((snapshot) {
      return snapshot.docs.map((doc) => doc.data() as Map<String, dynamic>).toList();
    });
  }
}
