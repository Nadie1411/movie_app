import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:movie_app/HomeScreen/Movie%20Details/movie_details.dart';
import 'package:movie_app/Themes/app_colors.dart';
import 'package:movie_app/Widgets/movies.dart';
import 'package:movie_app/data/end_points.dart';

import '../WatchList Tab/firestore/firebase_utils.dart';
import '../WatchList Tab/watchlist.dart';
import '../data/model/Response/MovieResponse.dart';

class MovieItemWithDetails extends StatefulWidget {
  Movie movie;
  bool isWishListed = false;
  Movies movies;

  MovieItemWithDetails({required this.movie,
    Movies? movies,
  }) : movies = movies ?? Movies(
    title: movie.title ?? '',
    overview: movie.overview ?? '',
    posterPath: movie.posterPath ?? '',
    releaseDate: movie.releaseDate ?? '',
    voteAverage: movie.voteAverage ?? 0.0,
  );





  @override
  
  State<MovieItemWithDetails> createState() => _MovieItemWithDetailsState();
}

class _MovieItemWithDetailsState extends State<MovieItemWithDetails> {
  bool isWishListed = false; // Declare Movies object






  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.pushNamed(context, MovieDetailsTab.routeName,
            arguments: widget.movie);
      },
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          color: AppColors.movieGreyColor,
          width: 100.87.w,
          height: 200.h,
          child:
          Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Container(
                    alignment: Alignment.center,
                    width: 100.87.w,
                    height: 100.74.h,
                    child: Expanded(
                      child: Container(
                        width: 96.87.w,
                        height: 127.74.h,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                              image: NetworkImage(
                                '${EndPoints.baseImageUrl}${widget.movie.posterPath}',
                              ),
                              fit: BoxFit.fitWidth,
                              alignment: Alignment.center),
                          borderRadius: BorderRadius.circular(4.r),
                        ),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  child: GestureDetector(
                    child: isWishListed
                        ? Image.asset(
                      'assets/images/bookmarked.png',
                      width: 27.w,
                      height: 36.h,
                    )
                        : Image.asset(
                      'assets/images/bookmark.png',
                      width: 27.w,
                      height: 36.h,
                    ),
    onTap: () {
    setState(() {
    isWishListed = !isWishListed;
    if (isWishListed) {
    Watchlist.addMovie(widget.movies);
    FirebaseUtils.addMovieToFireStore(widget.movies); // Add to Firestore
    } else {
    Watchlist.removeMovie(widget.movies);
    FirebaseUtils.removeMovieFromFireStore(widget.movies.id); // Remove from Firestore
    }
    });
    },

                      ////todo add to wish list

                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8.0, left: 8.0),
              child: Row(
                children: [
                  Icon(
                    Icons.star,
                    color: AppColors.primaryYellowColor,
                    size: 17,
                  ),
                  SizedBox(width: 5.w),
                  Text(
                    widget.movie.voteAverage.toString(),
                    style: Theme.of(context).textTheme.headlineMedium,
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: Text(
                widget.movie.title ?? '',
                style: Theme.of(context).textTheme.headlineMedium,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: Text(
                widget.movie.releaseDate ?? '',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
          ]),
        ),
      ),
    );
  }
}